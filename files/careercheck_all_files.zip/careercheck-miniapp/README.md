# CareerCheck — Telegram Mini App

Полноценный Web App внутри Telegram: 60 вопросов, Big Five, RIASEC, топ профессий.

## Структура

```
careercheck-miniapp/
├── miniapp/              ← React + Vite фронтенд
│   ├── src/
│   │   ├── App.jsx       ← Оркестратор экранов
│   │   ├── styles.css    ← Тёмная тема CareerCheck
│   │   ├── hooks/
│   │   │   └── useTelegram.js   ← Telegram WebApp API
│   │   ├── pages/
│   │   │   ├── WelcomePage.jsx  ← Приветствие
│   │   │   ├── QuizPage.jsx     ← 60 вопросов с анимациями
│   │   │   └── ResultsPage.jsx  ← Профиль + профессии
│   │   ├── components/
│   │   │   └── RadarChart.jsx   ← SVG-радар
│   │   └── utils/
│   │       └── calculator.js    ← Big Five + RIASEC на JS
│   └── vite.config.js    ← Билдит в ../webapp/dist
└── webapp/
    └── server.py         ← FastAPI: статика + REST API
```

## Установка и запуск

### 1. Зависимости Python

```bash
pip install fastapi uvicorn[standard] --break-system-packages
```

### 2. Сборка фронтенда

```bash
cd miniapp
npm install
npm run build
# → собирает в webapp/dist/
```

### 3. Запуск сервера

```bash
cd webapp
uvicorn server:app --host 0.0.0.0 --port 8080 --reload
```

Сервер отдаёт:
- `GET  /api/health`           → проверка
- `GET  /api/questions?lang=ru` → вопросы из БД
- `GET  /api/results/{tg_id}`  → результаты пользователя
- `POST /api/results/save`     → сохранить ответы и получить результат
- `GET  /*`                    → SPA (index.html)

## Регистрация Mini App в BotFather

1. Открой @BotFather → `/newapp`
2. Выбери своего бота
3. Укажи URL: `https://yourdomain.com` (нужен HTTPS!)
4. Добавь кнопку в бот:

```python
# В handlers.py — кнопка для открытия Mini App
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo

kb = InlineKeyboardMarkup(inline_keyboard=[[
    InlineKeyboardButton(
        text="🚀 Открыть тест",
        web_app=WebAppInfo(url="https://yourdomain.com")
    )
]])
```

## Интеграция с aiogram (handlers.py)

```python
# Обработчик данных из Mini App (если нужен)
@router.message(lambda m: m.web_app_data is not None)
async def handle_webapp_data(message: Message):
    data = json.loads(message.web_app_data.data)
    # data = {"telegram_id": ..., "results": {...}}
    await message.answer("✅ Результаты получены!")
```

## HTTPS для разработки

Mini App требует HTTPS. Варианты:
- **ngrok**: `ngrok http 8080` → получаешь HTTPS URL
- **Cloudflare Tunnel**: бесплатно, стабильно
- **Деплой на VPS**: certbot + nginx

## Docker (опционально)

```dockerfile
FROM python:3.11-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
CMD ["uvicorn", "webapp.server:app", "--host", "0.0.0.0", "--port", "8080"]
```

## Переменные окружения

Те же что в основном боте — `config/settings.py`:
- `BOT_TOKEN` — токен бота
- `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`

---

**@Dimirdin · CareerCheck**
